package com.hsbc.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.exceptions.UsernameException;

/**
 * Servlet implementation class OrderServlet
 */
@WebServlet({"/Jsp/OrderServlet","/viewbyid.htm","/viewproductbytype.htm","/login.jsp","/OrderManagement.jsp"})
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrderController action = new OrderController();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String url = request.getServletPath();
//		String view=null;
//		RequestDispatcher rd = null;
//		switch(url) {
//		
//			
//		case "/emplogin": 
//			System.out.println("hrkjkfgke");
//			view = action.processEmployeeLogin(request, response);
//			break;
//		}
//		
//		if(view!=null) {
//			rd = request.getRequestDispatcher(response.encodeUrl(view));
//			rd.forward(request, response);
//		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stubet(request, response);
		String url = request.getServletPath();
		System.out.println(url);

		String view=null;
		RequestDispatcher rd = null;
		HttpSession session = null;
		switch(url) {
		case "/OrderManagement.jsp":
			
			
			System.out.println("hrkjkfgke");
			view = action.processEmployeeLogin(request, response);
			System.out.println(view);
			
			if(view!=null) {
				session=request.getSession();  
				System.out.println("sessionID: "+session.getId());
			} else {
				view="login.jsp";  //if session==null
			}
			
			
			String msg= "username or password invalid";
			UsernameException e = new UsernameException("username or password invalid");
			request.setAttribute("msg", e.getMessage());
			break;
			
			
		case "/login.jsp":
			session=request.getSession(false);  
			System.out.println("sessionID: "+session.getId());
			if(session!=null) {
				view="OrderManagement.jsp";
			}
			break;
		}
		
		if(view!=null) {
			rd = request.getRequestDispatcher(response.encodeUrl(view));
			rd.forward(request, response);
		}
	}

}
