package com.hsbc.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.dao.IOrderDao;
import com.hsbc.dao.OrderDaoImpl;

import com.hsbc.exceptions.UsernameException;

public class OrderController {
	private IOrderDao dao = OrderDaoImpl.getDao();
	
	
	
	@SuppressWarnings("finally")
	public String processEmployeeLogin(HttpServletRequest request, HttpServletResponse response) throws IOException {
		boolean validUser = false;
		String username = request.getParameter("name");
		String password = request.getParameter("pwd");
		
		
		System.out.println(username+" "+ password);
		try {
			validUser = dao.empLoginDetails(username, password);
			System.out.println("validUswer: "+validUser);

			if(!validUser) {
				throw new UsernameException("username or password incorrect");
			}

//			if(validUser) {
//				return "OrderManagement.jsp";
//			}
//			else {
//				System.out.println("false is validUSewr");
//				return "login.jsp";
//			}
		} catch(UsernameException e) {
			System.out.println(e.getMessage());
			response.setStatus(404);
		}
		finally {
			if(validUser) {
				return "OrderManagement.jsp";
			}
			else {
				System.out.println("false is validUSewr");
				return "login.jsp";
			}
		}
	}
}
