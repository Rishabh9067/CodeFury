package com.hsbc.dao;

public interface HQueries {
	
	String getempid = "SELECT eid FROM Employee WHERE username=?";
	String getouttime = "SELECT lastlogin FROM loginDetails WHERE eid=?";
	String viewpdtbyusername = "SELECT * FROM Employee WHERE username=? and password=?";
}
