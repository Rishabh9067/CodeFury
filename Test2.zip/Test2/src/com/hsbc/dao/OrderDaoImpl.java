package com.hsbc.dao;

import java.io.IOException;
import java.text.DateFormat;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.hsbc.entity.Employee;

import com.hsbc.exceptions.UsernameException;

public class OrderDaoImpl implements IOrderDao {
	private static IOrderDao dao = new OrderDaoImpl();
	
	static {
		try {
			Class.forName(DatabaseConnection.getDbDriver());
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
	
	private OrderDaoImpl() {
		// TODO Auto-generated constructor stub
	}
	
	public static IOrderDao getDao() {
		return dao;
	}
	
	/**
	 * This method is used to get the customer information from the id
	 */
	

	@Override
	public boolean empLoginDetails(String username, String password) throws UsernameException {
		boolean validUser = false;
		try(Connection conn = DriverManager.getConnection(DatabaseConnection.getDbUrl())) {
			PreparedStatement st = conn.prepareStatement(HQueries.viewpdtbyusername);
			st.setString(1, username);
			st.setString(2, password);
			ResultSet rs = st.executeQuery();
			System.out.println("result sets printing ....");
			//System.out.println("resultset1: "+rs.getString("username"));
			if(rs.next()) {
				PreparedStatement st2 = conn.prepareStatement(HQueries.getempid);
				st2.setString(1, username);
				ResultSet rs2 = st2.executeQuery();
				System.out.println("resultset2: "+rs.getString("username"));
				
				if(rs2.next()) {
					System.out.println("resultset2: "+rs2.getInt("eid"));

					return lastLogDetails(rs2.getInt("eid"));

				}
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	public boolean lastLogDetails(int eid) {
		LocalDateTime now = LocalDateTime.now();
		
		System.out.println("now: " + now);
		
		try(Connection conn = DriverManager.getConnection(DatabaseConnection.getDbUrl())) {
			PreparedStatement st = conn.prepareStatement(HQueries.getouttime);
			st.setInt(1, eid);
			
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				
			LocalDateTime outTime = rs.getTimestamp("lastlogin").toLocalDateTime();	
			
			System.out.println("outTime: " + outTime);

			
			int flag = now.compareTo(outTime);
			
			System.out.println("flag: " + flag);

			
			if(flag<0)
				return true;}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	
		return false;
}
	
}
