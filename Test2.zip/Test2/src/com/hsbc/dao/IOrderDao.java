package com.hsbc.dao;

import java.util.Map;


import com.hsbc.entity.Employee;
import com.hsbc.exceptions.UsernameException;

public interface IOrderDao {
	
	boolean empLoginDetails(String username, String password) throws UsernameException; 
	
	
}
